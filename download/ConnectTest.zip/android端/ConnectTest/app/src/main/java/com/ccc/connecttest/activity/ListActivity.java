package com.ccc.connecttest.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import com.ccc.connecttest.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import util.HttpUtil;

public class ListActivity extends AppCompatActivity {
    private List<User> userList=new ArrayList<>();
    private ListView listView;

    private String json_url="http://192.168.2.133:8080/ConnectTest/ServletDemo1";//本地Tomcat刚才测试的地址

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        queryFromServer(json_url); //处理取得数据

        listView=findViewById(R.id.lv);
        UserAdapter adapter = new UserAdapter(ListActivity.this, R.layout.user, userList);
        listView.setAdapter(adapter);
    }

    private void queryFromServer(String json_url) {
        HttpUtil.sendOkHttpRequest(json_url, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.i("error","出现错误！");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText=response.body().string();
                try {
                    JSONArray jsonArray=new JSONArray(responseText);
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject=jsonArray.getJSONObject(i);
                        String id=jsonObject.getString("id");
                        String username=jsonObject.getString("username");
                        String password=jsonObject.getString("password");

                        User user=new User(Integer.parseInt(id),username,password);
                        userList.add(user);

                        Log.i("user","添加了一个User");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
